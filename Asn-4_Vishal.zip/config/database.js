module.exports = {
    url : "mongodb+srv://vishalgoud2020:VishalKanaka@cluster0.j7jfniz.mongodb.net/sales"
};
